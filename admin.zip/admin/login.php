<?php 
session_start(); 
include "config.php";

if (isset($_POST['uname']) && isset($_POST['password'])) {

	function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}

	$uname = validate($_POST['uname']);
	$pass = validate($_POST['password']);
	
	//Making sure that SQL Injection doesn't work
	$uname = mysqli_real_escape_string($con, $uname);//test or 1=1
	$pass = mysqli_real_escape_string($con, $pass);

	if (empty($uname)) {
		header("Location: index.php?error=User Name is required");
	    exit();
	}else if(empty($pass)){
        header("Location: index.php?error=Password is required");
	    exit();
	}else{
		$sql = "SELECT * FROM tbl_admin WHERE a_name='$uname' AND a_password='$pass'";

		$result = mysqli_query($con, $sql);

		if (mysqli_num_rows($result) === 1) {
			$row = mysqli_fetch_assoc($result);
            if ($row['a_name'] === $uname && $row['a_password'] === $pass) {
            	$_SESSION['a_name'] = $row['a_name'];
            	$_SESSION['a_name'] = $row['a_name'];
            	$_SESSION['a_id'] = $row['a_id'];
            	header("Location: home.php");
		        exit();
            }else{
				header("Location: index.php?error=Incorect User name or password");
		        exit();
			}
		}else{
			header("Location: index.php?error=Incorect User name or password");
	        exit();
		}
	}
	
}else{
	header("Location: index.php");
	exit();
}?>